import ast
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import time

root = Path('<verification-worktree>')
mode = sys.argv[1]
assert mode in ('bash', 'powershell')
state = Path('<verification-temp>/hook-resilience-v1-t10') / ('installed-' + mode)
state.mkdir(exist_ok=False)
home = state / "home with spaces ' fixture"
home.mkdir()
configs = {
    '.codex/hooks.json': {'setting': {'v1_keep': True}, 'hooks': {'BeforeTool': [{'hooks': [{'type': 'command', 'command': 'echo v1-custom-codex'}]}], 'SessionStart': [{'hooks': [{'type': 'command', 'command': 'echo v1-custom-startup'}]}]}},
    '.copilot/hooks/hooks.json': {'version': 1, 'v1_keep': True, 'hooks': {'preToolUse': [{'type': 'command', 'bash': 'echo v1-custom-copilot'}]}},
    '.gemini/settings.json': {'v1_keep': True, 'general': {'v1_keep': True}, 'hooks': {'BeforeTool': [{'matcher': 'v1-custom', 'hooks': [{'type': 'command', 'command': 'echo v1-custom-gemini'}]}]}},
}
for relative, value in configs.items():
    path = home / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))
env = os.environ.copy()
for key in tuple(env):
    if key.startswith(('COPILOT_OBSERVABILITY_', 'GEMINI_OBSERVABILITY_', 'OBSERVABILITY_')) or key in ('AUDIT_LOG', 'AUDIT_LOCK', 'AUDIT_PASSIVE_LOG_SHADOW_LOG', 'GEMINI_PASSIVE_SHADOW_LOG'):
        env.pop(key)
env.update(HOME=str(home), CODEX_HOME=str(home / '.codex'), XDG_CONFIG_HOME=str(state / 'shell-config'), XDG_CACHE_HOME=str(state / 'shell-cache'), XDG_DATA_HOME=str(state / 'shell-data'), PSModuleAnalysisCachePath=str(state / 'shell-module-cache'), OBSERVABILITY_TESTING='1', OBSERVABILITY_LOG_PATH=str(state / 'observability.jsonl'), PYTHONPYCACHEPREFIX=str(state / 'pycache'))
result = {'candidate': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(), 'installer': 'bash scripts/install.sh (child of rtk proxy verification harness)', 'passes': [], 'assets': [], 'diagnostics': {}, 'failures': []}
installer_command = ['bash', 'scripts/install.sh'] if mode == 'bash' else ['pwsh', '-NoProfile', '-NonInteractive', '-File', 'scripts/install.ps1']
result['installer'] = installer_command
started = time.monotonic()
with (state / 'installer.raw.log').open('w') as log:
    install = subprocess.run(installer_command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
result['installer_exit_code'] = install.returncode
result['installer_seconds'] = time.monotonic() - started
if install.returncode:
    result['failures'].append('actual installer failed')
else:
    tracked = subprocess.check_output(['git', 'ls-files', '.codex/hooks', '.copilot/hooks', '.gemini/hooks'], cwd=root, text=True).splitlines()
    codex_owned = {'.codex/hooks/' + item for item in shlex.split(re.search(r'^readonly CODEX_HOOK_FILES=\(([^\n]+)\)', (root / 'scripts/install.sh').read_text(), re.M)[1])}
    for relative in tracked:
        source = root / relative
        if source.suffix not in ('.py', '.sh') or (relative.startswith('.codex/') and relative not in codex_owned):
            continue
        installed = home / relative
        source_hash = hashlib.sha256(source.read_bytes()).hexdigest()
        installed_hash = hashlib.sha256(installed.read_bytes()).hexdigest() if installed.is_file() else None
        mode = stat.S_IMODE(installed.stat().st_mode) if installed.is_file() else None
        okay = source_hash == installed_hash and mode == 0o755
        result['assets'].append({'path': relative, 'source_sha256': source_hash, 'installed_sha256': installed_hash, 'installed_mode': oct(mode) if mode is not None else None, 'pass': okay})
        if not okay:
            result['failures'].append('asset mismatch: ' + relative)
    for relative, original in configs.items():
        actual = json.loads((home / relative).read_text())
        if relative.startswith('.codex'):
            okay = actual['setting'] == original['setting'] and actual['hooks']['BeforeTool'] == original['hooks']['BeforeTool'] and actual['hooks']['SessionStart'][0] == original['hooks']['SessionStart'][0]
        elif relative.startswith('.copilot'):
            okay = actual['v1_keep'] is True and original['hooks']['preToolUse'][0] in actual['hooks']['preToolUse']
        else:
            okay = actual['v1_keep'] is True and actual['general']['v1_keep'] is True and original['hooks']['BeforeTool'][0] in actual['hooks']['BeforeTool']
        result['passes'].append({'check': 'preserved user registrations and settings', 'config': relative, 'pass': okay})
        if not okay:
            result['failures'].append('user registration/settings mismatch: ' + relative)
    for provider, relative in [('codex','.codex/hooks/hooks-diagnostics.py'),('copilot','.copilot/hooks/scripts/hooks-diagnostics.py'),('gemini','.gemini/hooks/scripts/hooks-diagnostics.py')]:
        before = {name: (home / name).read_bytes() for name in configs}
        launch = subprocess.run([sys.executable, '-I', '-S', '-B', str(home / relative), '--doctor'], cwd=home, env=env, capture_output=True, timeout=5)
        report = json.loads(launch.stdout)
        expected_build = next(node.value.value for node in ast.parse((root / relative).read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'DIAG_BUILD' for target in node.targets))
        okay = launch.returncode == 0 and len(launch.stdout) <= 16384 and report['provider'] == provider and report['bootstrap']['embedded_build'] == expected_build and report['security']['outcome'] == 'not_scanned' and report['audit']['outcome'] == 'not_attempted' and report['assets']['complete'] and all(item['state'] in ('matches', 'unverified') for item in report['assets']['records']) and report['registrations']['missing'] == 0 and report['registrations']['duplicates'] == 0 and all((home / name).read_bytes() == content for name, content in before.items())
        result['diagnostics'][provider] = {'expected_embedded_build': expected_build, 'exit_code': launch.returncode, 'stdout_bytes': len(launch.stdout), 'report': report, 'nonmutating_not_scanned_pass': okay}
        if not okay:
            result['failures'].append('diagnostics failure: ' + provider)
    result['installed_config_sha256'] = {relative: hashlib.sha256((home / relative).read_bytes()).hexdigest() for relative in configs}
    before = {str(path.relative_to(home)): [hashlib.sha256(path.read_bytes()).hexdigest(), stat.S_IMODE(path.stat().st_mode)] for path in home.rglob('*') if path.is_file() and not path.is_symlink()}
    with (state / 'installer-second.raw.log').open('w') as log:
        second = subprocess.run(installer_command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    after = {str(path.relative_to(home)): [hashlib.sha256(path.read_bytes()).hexdigest(), stat.S_IMODE(path.stat().st_mode)] for path in home.rglob('*') if path.is_file() and not path.is_symlink()}
    result['second_installer_exit_code'] = second.returncode
    result['full_home_files_idempotent'] = before == after
    result['full_home_changed_files'] = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
    result['full_home_file_fingerprint_before'] = hashlib.sha256(json.dumps(before, sort_keys=True).encode()).hexdigest()
    result['full_home_file_fingerprint_after'] = hashlib.sha256(json.dumps(after, sort_keys=True).encode()).hexdigest()
    if second.returncode or before != after:
        result['failures'].append('repeat installation not file/mode idempotent')
result['pass'] = not result['failures']
(state / 'installed-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'pass': result['pass'], 'assets_checked': len(result['assets']), 'installer_exit_code': install.returncode, 'failures': result['failures']}))
raise SystemExit(0 if result['pass'] else 1)
