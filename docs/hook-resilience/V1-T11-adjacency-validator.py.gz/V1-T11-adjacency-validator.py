from collections import Counter
import json
from pathlib import Path
import runpy
import statistics
import sys

state=Path('<verification-temp>/hook-resilience-v1-t11')
freeze=json.loads((state/'freeze.json').read_text())
root=Path(freeze['candidate_root'])
sys.path.insert(0,str(root/'scripts'))
namespace=runpy.run_path(str(root/'scripts/verify-hook-release.py'),run_name='V1_T11_adjacency')
report=json.loads((state/'evidence/timing.json').read_text())
cases=[c.name for c in namespace['selected_cases'](root,'candidate',[],'timing')]
rows={(r['pair'],r['case'],r['condition']):r for r in report['warm']}
assert len(rows)==624
events=[]
for (pair,case,condition),row in rows.items():
    assert len(row['invocations'])==29
    for index,observation in enumerate(row['invocations']):
        assert observation['call_index']==index
        kind='first' if index==0 else 'warmup' if index<=3 else 'measured'
        assert observation['kind']==kind
        start=observation['start_monotonic_ns'];end=observation['end_monotonic_ns']
        assert isinstance(start,int) and isinstance(end,int) and end>start>0
        events.append((start,end,pair,case,index,condition,kind))
        if index==0:
            assert 0<row['first_process_ms']<=(end-start)/1e6
        elif index>=4:
            assert 0<row['samples_ms'][index-4]<=(end-start)/1e6
    assert row['summary']==namespace['high_rate'].summary(row['samples_ms'])
events.sort()
assert len(events)==18096
expected=[(pair,case,index,label,'first' if index==0 else 'warmup' if index<=3 else 'measured') for pair,order in enumerate(namespace['ORDER']) for case in cases for index in range(29) for label in order]
assert [(p,c,i,label,k) for start,end,p,c,i,label,k in events]==expected
assert all(a[1]<=b[0] for a,b in zip(events,events[1:]))
matched_gaps=[(events[i+1][0]-events[i][1])/1e6 for i in range(0,len(events),2)]
matched_starts=[(events[i+1][0]-events[i][0])/1e6 for i in range(0,len(events),2)]
assert len(matched_gaps)==9048
for comparison in report['comparisons']:
    if comparison['phase'].startswith('warm'):
        pair=int(comparison['phase'][-1])-1
        baseline=rows[pair,comparison['case'],'baseline']['summary']
        candidate=rows[pair,comparison['case'],'candidate']['summary']
        for metric in ['median_ms','p95_ms']:
            assert comparison['delta_ms'][metric]==candidate[metric]-baseline[metric]
assert report['method']['warm_order']==[['baseline','candidate'],['candidate','baseline']]
assert report['method']['samples']==25 and report['method']['warmups']==3
assert report['method']['cold_launches_per_case_condition']==25
assert report['method']['exact_case_filter']==[]
result={'candidate':freeze['candidate'],'warm_rows':624,'invocations':18096,'matched_adjacent_launches':9048,'calls_per_row':29,'kinds':dict(Counter(x[-1] for x in events)),'ordered_nonoverlapping_intervals':True,'exact_pair_case_call_source_order':True,'inner_elapsed_preserved':True,'independent_summary_and_delta_recomputed':True,'matched_gap_ms':{'min':min(matched_gaps),'median':statistics.median(matched_gaps),'max':max(matched_gaps)},'matched_start_separation_ms':{'min':min(matched_starts),'median':statistics.median(matched_starts),'max':max(matched_starts)}}
(state/'evidence/adjacency-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
