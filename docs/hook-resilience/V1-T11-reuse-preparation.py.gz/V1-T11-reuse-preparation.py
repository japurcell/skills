import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import runpy
import stat
import subprocess
import sys

root=Path('<verification-worktree>')
state=Path('<verification-temp>/hook-resilience-v1-t11')
state.mkdir()
(state/'evidence').mkdir()
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root,text=True)
candidate=git('rev-parse','HEAD').strip()
assert candidate.startswith('81fe28bb')
assert not git('status','--porcelain')
paths=['hooks','.codex/hooks','.copilot/hooks','.gemini/hooks','.github/hooks','.codex/global-hooks.json','.copilot/hooks/hooks.json','.gemini/global-settings.json','scripts/benchmark-high-rate-hooks.py','scripts/benchmark-tool-guard-resources.py','scripts/tool_guard_corpus.py','scripts/fixtures/tool_guard_vectors.py','scripts/test-all.py','scripts/install.sh','scripts/install.ps1','scripts/install-codex-hooks.py','scripts/install-provider-hooks.py','scripts/trusted_hook_launch.py']
assert not git('diff','--name-only','1817d569','HEAD','--',*paths)
assert not git('diff','--name-only','19518f2','HEAD','--','scripts/verify-hook-release.py','scripts/test-verify-hook-release.py')
old=ast.parse(git('show','1817d569:scripts/verify-hook-release.py'))
new=ast.parse((root/'scripts/verify-hook-release.py').read_text())
oldf={n.name:n for n in old.body if isinstance(n,ast.FunctionDef)}
newf={n.name:n for n in new.body if isinstance(n,ast.FunctionDef)}
same=[]
for name in ['warm_run','measure_resources','summary','comparisons','compare']:
    if name in oldf:
        assert ast.dump(oldf[name])==ast.dump(newf[name]),name
        same.append(name)
assert ast.dump(oldf['checked_invocation'].body[0])==ast.dump(newf['checked_invocation'].body[0].body[0])
assert ast.dump(oldf['checked_invocation'].body[-1])==ast.dump(newf['checked_invocation'].body[-1])
mapping=json.loads((root/'docs/hook-resilience/V1-T10-functional-map.json').read_text())
for row in mapping['rows']:
    if row['suite_path']=='scripts/test-verify-hook-release.py':
        row.update(current_status='passed_T11_fresh',current_result={'tests':15,'seconds':2.818,'exit_code':0},evidence=['T11-evidence.md'],basis='Integrated adapter/tests byte-identical to tested19518f2; deterministic/public CLI adjacency, failure retention, counts, statistics and native resource mechanics pass.')
    if row['suite_path']=='scripts/test-benchmark-high-rate-hooks.py':
        row.update(current_status='passed_T11_fresh',current_result={'tests':2,'seconds':15.468,'exit_code':0},evidence=['T11-evidence.md'],basis='Fresh T11 maintained high-rate test result on identical integrated source.')
mapping.update(candidate=candidate,prior_candidate='1817d569b42008019ec66d3ac3469f7fd704308c',registry_focused_T11={'command':'rtk proxy python3 scripts/test_test_all.py','tests':14,'seconds':11.068,'exit_code':0},counts=dict(Counter(r['current_status'] for r in mapping['rows'])))
mapping['V1_complete']=False
(state/'functional-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
original=[{'path':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted((root/'docs/hook-resilience').glob('V1-*'))]
(state/'original-artifacts-preserved.json').write_text(json.dumps({'artifacts':original},indent=2)+'\n')
proof={'candidate':candidate,'runtime_matches':'1817d569b42008019ec66d3ac3469f7fd704308c','T11_matches_tested':'19518f2','unchanged_owning_paths':paths,'ast_identical_adapter_functions':same,'checked_invocation_default_invoke_and_return_unchanged':True,'resource_reuse':{'source':'V1-T10-resources.json.gz','rows':216,'cases_per_condition':108,'eligible':True,'basis':'Runtime, maintained resource/high-rate runners, corpus, builder cases, budgets, measure_resources and warm_run unchanged; resource/cold/concurrency callers use checked_invocation default None path with identical invoke and return. Existing full native RSS/log/decision proof remains valid. T11 adapter15 adds approved native separate RSS mechanics proof; no changed resource interaction or unverified gap requires full rerun.'},'installed_reuse':{'source':['V1-T10-installed-bash.json','V1-T10-installed-powershell.json'],'basis':'All runtime/installers/trusted launch/config source and modes unchanged; T11 only changes release adapter warm scheduling and adapter tests, outside installed runtime.'},'functional_counts':mapping['counts']}
(state/'source-reuse.json').write_text(json.dumps(proof,indent=2)+'\n')
inventory=json.loads((root/'docs/hook-resilience/V1-T10-runtime-fingerprints.json').read_text())
for name,v in inventory['files'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==v['sha256']
    assert oct(stat.S_IMODE((root/name).stat().st_mode))==v['mode']
inventory['candidate']=candidate
(state/'runtime-fingerprints.json').write_text(json.dumps(inventory,indent=2)+'\n')
baseline='bc52d7d69aaa046ea97e323879402241a01fead7'
archive=state/'baseline.tar'
subprocess.run(['git','archive','--format=tar','--output='+str(archive),baseline],cwd=root,check=True)
baseline_root=state/'baseline'
baseline_root.mkdir()
subprocess.run(['tar','-x','-f',str(archive),'-C',str(baseline_root)],check=True)
sys.path.insert(0,str(root/'scripts'))
namespace=runpy.run_path(str(root/'scripts/verify-hook-release.py'),run_name='V1_T11_declarations')
cases=[]
for mode,count in [('resources',108),('timing',156)]:
    for condition,path in [('baseline',baseline_root),('candidate',root)]:
        selected=namespace['selected_cases'](path,condition,[],mode)
        assert len(selected)==count
        for case in selected:
            cases.append({'mode':mode,'condition':condition,'case':case.name,'expected_decision':case.expected_decision,'input_sha256':hashlib.sha256(case.payload).hexdigest()})
old_cases=json.loads((Path('<verification-temp>/hook-resilience-v1-t10/evidence/declared-cases.json')).read_text())['cases']
assert cases==old_cases
(state/'evidence/declared-cases.json').write_text(json.dumps({'candidate':candidate,'basis':'Frozen builders; declared before timing, identical expected decisions/input hashes to full T10 resources/timing; never from outcomes','cases':cases},indent=2)+'\n')
freeze={'candidate':candidate,'reviewed_source':'8f250431','baseline':baseline,'baseline_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'baseline_root':str(baseline_root),'candidate_root':str(root),'evidence_dir':str(state/'evidence'),'runtime_inventory_sha256':inventory['inventory_sha256'],'harness_sha256':namespace['harness_fingerprints'](),'runtime_assets':len(inventory['files']),'candidate_clean':True,'functional_checks_finished':False,'freshness':'pending','coordinator_quiet_system_authorized':False,'resources_reused':'V1-T10-resources.json.gz'}
(state/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
for source,target in [('hook-v1-t10-release-run.py','hook-v1-t11-release-run.py'),('hook-v1-t10-analyze-release.py','hook-v1-t11-analyze-release.py'),('hook-v1-t10-summarize-timing.py','hook-v1-t11-summarize-timing.py'),('hook-v1-t10-performance-ranges.py','hook-v1-t11-performance-ranges.py')]:
    text=(Path('/private/tmp')/source).read_text().replace('<verification-temp>/hook-resilience-v1-t10','<verification-temp>/hook-resilience-v1-t11')
    (Path('/private/tmp')/target).write_text(text)
print(json.dumps({'candidate':candidate,'counts':mapping['counts'],'resources_reuse':True,'installed_reuse':True,'declared_cases_identical':True,'runtime_assets':len(inventory['files'])}))
