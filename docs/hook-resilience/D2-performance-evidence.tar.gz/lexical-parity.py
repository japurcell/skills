import importlib.util,sys,json,random,types
from pathlib import Path
out=Path('/private/tmp/hook-resilience-d2');mods=[]
for variant in ['original','structural-tokens']:
 p=out/'ablation-source'/variant/'.codex/hooks/helpers/common.py';s=importlib.util.spec_from_file_location(variant,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);mods.append(m)
rng=random.Random(73);tests=[]
alphabet='abcXYZ09 "\\{}[]\n\t\r'+'éλ漢'
for i in range(1000):
 value=''.join(rng.choices(alphabet,k=rng.randrange(0,200)))
 raw=json.dumps({'x':value,'a':[i,{'q':'\\"'*3}]},ensure_ascii=i%2==0).encode()
 tests.append(raw)
 if i%4==0:tests.append(raw+b' trailing')
 if i%4==1:tests.append(raw[:-rng.randrange(1,min(10,len(raw)))])
tests += [b'{"x":' + b'['*n+b'0'+b']'*n+b'}' for n in [62,63,64,65]]
count=0
for raw in tests:
 for width in [1,2,3,7,64,65536]:
  outcomes=[]
  for m in mods:
   chunks=[raw[i:i+width] for i in range(0,len(raw),width)]
   m.os=types.SimpleNamespace(read=lambda fd,size:chunks.pop(0) if chunks else b'')
   m.sys=types.SimpleNamespace(stdin=types.SimpleNamespace(fileno=lambda:0))
   m.time=types.SimpleNamespace(monotonic=lambda:0)
   m._stdin_is_ready=lambda fd,timeout=0:True
   try: value=json.loads(m._read_json_input_text());outcomes.append(('value',value))
   except (ValueError,OSError):outcomes.append(('deny',))
  if outcomes[0]!=outcomes[1]:raise AssertionError((raw,width,outcomes))
  count+=1
report={'kind':'disposable lexical parity only; not public or release acceptance','seed':73,'inputs':len(tests),'chunk_widths':[1,2,3,7,64,65536],'matched_cases':count,'mismatches':0}
(out/'lexical-parity.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
