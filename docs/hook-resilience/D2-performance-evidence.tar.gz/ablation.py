import importlib.util,sys,json,hashlib,shutil
from pathlib import Path
root=Path('/Users/adam/.codex/worktrees/hook-performance-diagnosis/skills');sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('release',root/'scripts/verify-hook-release.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path('/private/tmp/hook-resilience-d2'); repo=out/'repo'
roots={}
for variant in ['original','label-prefilter','json-ascii']:
 dest=out/'ablation-source'/variant
 for provider in m.PROVIDERS:m.copy_provider(root,dest,provider)
 for path in dest.rglob('tool_guard_policy.py'):
  text=path.read_text()
  if variant=='label-prefilter':
   needle='    # Labels have no need to reproduce a credential-bearing identifier.'
   inserted='    # DIAGNOSTIC ABLATION ONLY: an ASCII prefilter retains the original regex authority.\n    markers = ("ghp_", "gho_", "ghu_", "ghs_", "ghr_", "github_pat_", "akia", "sk-", "sk_live_", "xoxb-", "xoxa-", "xoxp-", "xoxr-", "xoxs-", "bearer", "token", "secret", "password", "passwd", "api", "authorization", "http")\n    if text.isascii() and not any(marker in text.lower() for marker in markers):\n        return report_text(text)\n'
   assert needle in text;text=text.replace(needle,inserted+needle)
  if variant=='json-ascii':
   needle='    if isinstance(value, str):\n        return 2 + sum('
   replacement='    if isinstance(value, str):\n        # DIAGNOSTIC ABLATION ONLY: exact printable ASCII cost in C string operations.\n        if value.isascii() and value.isprintable():\n            return 2 + len(value) + value.count(chr(34)) + value.count(chr(92))\n        return 2 + sum('
   assert needle in text;text=text.replace(needle,replacement)
  path.write_text(text)
 roots[variant]=dest
report={'kind':'diagnostic single-factor ablation; not release acceptance','method':{'samples':25,'warmups':3,'pair_order':[['original','label-prefilter','json-ascii'],['json-ascii','label-prefilter','original']],'logging':'maintained successful-log verification','bytecode':'normal warm copies'},'rows':[],'fingerprints':{v:m.resources.fingerprints(p) for v,p in roots.items()}}
names=['copilot.guard.clean','copilot.guard.writer.chars-8787-segments-183','gemini.guard.write.utf8-growth','codex.guard.search.literal']
for pair,order in enumerate(report['method']['pair_order']):
 for name in names:
  for variant in order:
   case=m.selected_cases(roots[variant],'candidate',[name],'timing')[0]
   row={'pair':pair,'condition':variant,'case':name,'input_sha256':hashlib.sha256(case.payload).hexdigest()};report['rows'].append(row)
   m.warm_run(case,roots[variant],repo,out/'ablation-home'/str(pair)/variant/name,25,3,row)
   print(pair,variant,name,row['summary'],flush=True)
report['sources_unchanged']=report['fingerprints']=={v:m.resources.fingerprints(p) for v,p in roots.items()}
(out/'ablation.json').write_text(json.dumps(report,indent=2))
