import importlib.util,sys,json,hashlib
from pathlib import Path
root=Path('/Users/adam/.codex/worktrees/hook-performance-diagnosis/skills');sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('release',root/'scripts/verify-hook-release.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path('/private/tmp/hook-resilience-d2');repo=out/'repo';variants=['original','label-prefilter','json-ascii'];roots={v:out/'ablation-source'/v for v in variants}
report={'kind':'diagnostic interleaved full subprocess; not release acceptance','samples':50,'warmups':3,'rows':[],'fingerprints':{v:m.resources.fingerprints(p) for v,p in roots.items()}}
for name in ['copilot.guard.clean','gemini.guard.write.utf8-growth','codex.guard.search.literal']:
 cases={};homes={};rows={v:[] for v in variants}
 for v in variants:
  cases[v]=m.prepared_case(m.selected_cases(roots[v],'candidate',[name],'timing')[0],roots[v]);homes[v]=out/'interleaved-home'/v/name;homes[v].mkdir(parents=True,exist_ok=True)
  for i in range(3):m.checked_invocation(cases[v],repo,homes[v])
 for i in range(50):
  order=variants if i%2==0 else list(reversed(variants))
  for v in order:
   elapsed,output=m.checked_invocation(cases[v],repo,homes[v]);rows[v].append(elapsed)
 for v in variants:
  proof=m.verify_logging(homes[v],cases[v],53);m.logging_error(proof)
  row={'case':name,'condition':v,'samples_ms':rows[v],'summary':m.high_rate.summary(rows[v]),'logging':proof};report['rows'].append(row)
  if v!='original': row['paired_delta_ms']=m.high_rate.summary([a-b for a,b in zip(rows[v],rows['original'])])
  print(name,v,row['summary'],row.get('paired_delta_ms'),flush=True)
report['sources_unchanged']=report['fingerprints']=={v:m.resources.fingerprints(p) for v,p in roots.items()}
(out/'interleaved.json').write_text(json.dumps(report,indent=2))
