import importlib.util,sys,json,subprocess,pstats,hashlib
from pathlib import Path
root=Path('/Users/adam/.codex/worktrees/hook-performance-diagnosis/skills')
sys.path.insert(0,str(root/'scripts'))
spec=importlib.util.spec_from_file_location('release',root/'scripts/verify-hook-release.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
out=Path('/private/tmp/hook-resilience-d2'); repo=out/'repo';m.high_rate.make_repo(repo,'clean')
roots={'baseline':Path('/private/tmp/hook-resilience-v1-phase2/baseline'),'candidate':root}
names=['copilot.guard.clean','gemini.guard.write.utf8-growth','codex.guard.search.literal']
report=[]
for condition,src in roots.items():
 frozen=out/'profile-source'/condition
 for provider in m.PROVIDERS:m.copy_provider(src,frozen,provider)
 for case in m.selected_cases(src,condition,names,'timing'):
  home=out/'profile-home'/condition/case.name;home.mkdir(parents=True,exist_ok=True)
  case=m.prepared_case(case,frozen)
  # Ordinary launch establishes bytecode before profiling, without modifying frozen source.
  m.checked_invocation(case,repo,home)
  paths=[]
  for n in range(3):
   dest=out/f'{condition}-{case.name}-{n}.prof';paths.append(dest)
   proc=subprocess.run([sys.executable,'-m','cProfile','-o',str(dest),str(case.script)],input=case.payload,cwd=repo,env=m.high_rate.invocation_environment(case,home),capture_output=True)
   m.high_rate.verify_outcome(case,proc.returncode,json.loads(proc.stdout))
  stats=pstats.Stats(*map(str,paths))
  filtered=[]
  for (file,line,name),(cc,nc,tt,ct,callers) in stats.stats.items():
   if 'hooks/' in file or 're/' in file or name in ['compile','_compile','_compile_pattern']:
    filtered.append({'file':file,'line':line,'name':name,'calls':nc/3,'self_ms':tt/3*1000,'cum_ms':ct/3*1000})
  filtered.sort(key=lambda x:x['cum_ms'],reverse=True)
  proof=m.verify_logging(home,case,4);m.logging_error(proof)
  report.append({'condition':condition,'case':case.name,'input_bytes':len(case.payload),'input_sha256':hashlib.sha256(case.payload).hexdigest(),'logging':proof,'profile':filtered})
 (out/'profile.json').write_text(json.dumps(report,indent=2))
for x in report:
 print(x['condition'],x['case'],x['input_bytes'])
 for row in x['profile'][:16]:print(row['name'],round(row['cum_ms'],3),round(row['self_ms'],3),row['calls'])
