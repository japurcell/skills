#!/usr/bin/env python3
"""D3 diagnostics only. Never release acceptance; retained outcomes, no filtering."""
import importlib.util
import sys
from pathlib import Path
import json
import hashlib
import time
from dataclasses import replace

ROOT = Path('/Users/adam/.codex/worktrees/hook-residual-diagnosis/skills')
BASE = Path('/private/tmp/hook-resilience-v1-phase2/baseline')
OUT = Path('/private/tmp/hook-resilience-d3')
NAMES = ['copilot.guard.danger.remove_env_file', 'gemini.guard.danger.drop_database',
         'codex.guard.danger.forced_git_clean', 'codex.guard.survey.analysis-source',
         'codex.guard.patch.lines-330', 'codex.guard.clean']
sys.path.insert(0, str(ROOT / 'scripts'))
spec = importlib.util.spec_from_file_location('verify_d3', ROOT / 'scripts/verify-hook-release.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)

def main():
    OUT.mkdir(exist_ok=True)
    if (OUT / 'controls.json').exists():
        raise SystemExit('refuse overwrite')
    roots = {'baseline': BASE, 'candidate': ROOT}
    before = {k: v.resources.fingerprints(p) for k,p in roots.items()}
    assert before['baseline'] == v.baseline_fingerprints()
    report = {'diagnostic_only': True, 'release_acceptance_eligible': False,
              'roots': {k:str(p) for k,p in roots.items()}, 'fingerprints_before': before,
              'harness': v.harness_fingerprints(), 'interpreter': sys.executable,
              'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'cases': NAMES, 'rows': [], 'errors': [], 'started_unix_ns': time.time_ns()}
    repo = OUT / 'repo'
    v.high_rate.make_repo(repo, 'clean')
    cases = {k: {c.name:c for c in v.release_cases(p,k) if c.name in NAMES} for k,p in roots.items()}
    frozen = {}
    for label,source in [('baseline-a',BASE),('baseline-b',BASE),('baseline',BASE),('candidate',ROOT)]:
        frozen[label] = OUT / 'source' / label
        for provider in v.PROVIDERS:
            v.copy_provider(source, frozen[label], provider)

    def newrow(phase,pair,label,name):
        source_condition = 'candidate' if label == 'candidate' else 'baseline'
        case = v.prepared_case(cases[source_condition][name], frozen[label])
        home = OUT / 'homes' / phase / str(pair) / label / name
        home.mkdir(parents=True)
        row = {'phase':phase,'pair':pair,'condition':label,'case':name,
               'payload_bytes':len(case.payload), 'payload_sha256':hashlib.sha256(case.payload).hexdigest(),
               'calls':[], 'home':str(home.relative_to(OUT)), 'bytecode_before':len(list(case.script.parent.rglob('*.pyc')))}
        report['rows'].append(row)
        return row,case,home

    def invoke(row,case,home,index):
        start = time.time_ns()
        elapsed,outcome = v.checked_invocation(case,repo,home)
        row['calls'].append({'index':index,'start_unix_ns':start,'end_unix_ns':time.time_ns(),
                             'kind':'first' if index==0 else 'warmup' if index<=3 else 'measured',
                             'elapsed_ms':elapsed,'outcome':outcome})

    def finish(row,case,home):
        row['summary'] = v.high_rate.summary([x['elapsed_ms'] for x in row['calls'] if x['kind']=='measured'])
        row['logging'] = v.verify_logging(home,case,len(row['calls']))
        v.logging_error(row['logging'])
        row['bytecode_after'] = len(list(case.script.parent.rglob('*.pyc')))

    try:
        # Exact existing block shape, but both labels run the same baseline bytes.
        for pair,order in enumerate((('baseline-a','baseline-b'),('baseline-b','baseline-a'))):
            for label in order:
                for name in NAMES:
                    row,case,home = newrow('same-source-block',pair,label,name)
                    for index in range(29):
                        invoke(row,case,home,index)
                    finish(row,case,home)
        # Two independent 25-sample pairs; alternate labels after every launch.
        for pair in (0,1):
            for name in NAMES:
                current = {label:newrow('source-interleaved',pair,label,name) for label in ('baseline','candidate')}
                for index in range(29):
                    order = ('baseline','candidate') if (index+pair)%2==0 else ('candidate','baseline')
                    for label in order:
                        invoke(*current[label],index)
                for row,case,home in current.values():
                    finish(row,case,home)
    except BaseException as exc:
        report['errors'].append(type(exc).__name__+': '+str(exc))
        raise
    finally:
        report['ended_unix_ns'] = time.time_ns()
        report['fingerprints_after'] = {k:v.resources.fingerprints(p) for k,p in roots.items()}
        report['sources_unchanged'] = before == report['fingerprints_after']
        report['harness_unchanged'] = report['harness'] == v.harness_fingerprints()
        (OUT/'controls.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__ == '__main__':
    main()
