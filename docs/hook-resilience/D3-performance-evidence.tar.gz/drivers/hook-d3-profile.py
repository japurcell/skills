#!/usr/bin/env python3
"""Profile complete real hook execution, with native outputs and audit checks."""
import sys
import subprocess
import json
import pstats
from pathlib import Path
sys.path.insert(0,'/private/tmp')
import importlib.util
s=importlib.util.spec_from_file_location('control','/private/tmp/hook-d3-control.py')
c=importlib.util.module_from_spec(s)
s.loader.exec_module(c)
v=c.v
out=c.OUT/'profiles'
out.mkdir(exist_ok=True)
report={'diagnostic_only':True,'interpreter':sys.executable,'rows':[]}
for condition,root in [('baseline',c.BASE),('candidate',c.ROOT)]:
    cases={x.name:x for x in v.release_cases(root,condition)}
    for name in c.NAMES:
        for index in range(3):
            home=out/condition/name/str(index)
            home.mkdir(parents=True)
            case=v.prepared_case(cases[name],c.OUT/'source'/condition)
            profile=home/'call.prof'
            cmd=[sys.executable,'-m','cProfile','-o',str(profile),str(case.script)]
            result=subprocess.run(cmd,input=case.payload,capture_output=True,cwd=c.OUT/'repo',env=v.high_rate.invocation_environment(case,home),timeout=15)
            output=json.loads(result.stdout)
            v.high_rate.verify_outcome(case,result.returncode,output)
            proof=v.verify_logging(home,case,1)
            v.logging_error(proof)
            stats=pstats.Stats(str(profile))
            rows=[{'file':fn,'line':ln,'function':fun,'primitive_calls':data[0],'total_calls':data[1],'self_seconds':data[2],'cumulative_seconds':data[3]} for (fn,ln,fun),data in stats.stats.items()]
            report['rows'].append({'condition':condition,'case':name,'index':index,'output':output,'exit_code':result.returncode,'logging':proof,'total_seconds':stats.total_tt,'stats':sorted(rows,key=lambda x:x['cumulative_seconds'],reverse=True)})
(out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
