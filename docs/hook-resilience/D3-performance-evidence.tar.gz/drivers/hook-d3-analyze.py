#!/usr/bin/env python3
"""Derive D3 evidence without dropping samples or changing gate statistics."""
import json
import hashlib
import statistics as st
import importlib.util
from pathlib import Path
s=importlib.util.spec_from_file_location('control','/private/tmp/hook-d3-control.py')
c=importlib.util.module_from_spec(s)
s.loader.exec_module(c)
v=c.v
original=Path('/private/tmp/hook-resilience-v1-t10/evidence/timing.json')
d=json.loads(original.read_text())
controls=json.loads((c.OUT/'controls.json').read_text())
profiles=json.loads((c.OUT/'profiles/summary.json').read_text())
out={'original_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),
     'original_failures':[x for x in d['comparisons'] if not x['met']],
     'original_selected_warm_rows':[x for x in d['warm'] if x['case'] in c.NAMES],
     'original_provider_case_delta_medians':[], 'original_same_baseline_pair_shifts':[],
     'original_block_lower_bounds':[], 'control_comparisons':[], 'profile_medians_ms':[]}
for provider in v.PROVIDERS:
    for phase in ('warm-pair-1','warm-pair-2','cold'):
        out['original_provider_case_delta_medians'].append({'provider':provider,'phase':phase,
            'median_ms':st.median(x['delta_ms']['median_ms'] for x in d['comparisons'] if x['phase']==phase and x['case'].startswith(provider+'.'))})
for x in d['pair_variation']:
    if x['condition']=='baseline':
        out['original_same_baseline_pair_shifts'].append({'case':x['case'],
             'median_ms':x['median_ms'][1]-x['median_ms'][0], 'p95_ms':x['p95_ms'][1]-x['p95_ms'][0]})
for pair in (0,1):
    for condition in ('baseline','candidate'):
        rows=[x for x in d['warm'] if x['pair']==pair and x['condition']==condition]
        out['original_block_lower_bounds'].append({'pair':pair,'condition':condition,
            'seconds':sum(x['first_process_ms']+sum(x['samples_ms']) for x in rows)/1000,
            'excludes':'three warmup durations per case and all validation/copy/driver overhead'})
for a in controls['rows']:
    if a['condition'] not in ('baseline-a','baseline'):
        continue
    b=next(b for b in controls['rows'] if b['phase']==a['phase'] and b['pair']==a['pair'] and b['case']==a['case'] and b['condition'] in ('baseline-b','candidate'))
    gate=v.compare(a['case'],a['phase']+'-pair-'+str(a['pair']+1),{'baseline':a['summary'],'candidate':b['summary']},2,5)
    gate['labels']=[a['condition'],b['condition']]
    gap=[abs(b['calls'][i]['start_unix_ns']-a['calls'][i]['start_unix_ns'])/1e9 for i in range(29)]
    gate['matched_start_separation_seconds']={'min':min(gap),'median':st.median(gap),'max':max(gap)}
    out['control_comparisons'].append(gate)
frozen={label:v.resources.fingerprints(c.OUT/'source'/label) for label in ('baseline-a','baseline-b','baseline','candidate')}
out['frozen_copy_fingerprints_after']=frozen
out['frozen_copies_match_original_provider_files']=all(
    data=={k:h for k,h in controls['fingerprints_before']['candidate' if label=='candidate' else 'baseline'].items() if not k.startswith('hooks/')}
    for label,data in frozen.items())
functions=('read_json_input','_read_json_input_text','_read_stdin_chunk','report_label','report_json_bytes','guard_report','record_guard','sanitize_tool_name','build_input_threats','build_block_reason','build_action_excerpt','_native_shell_shape','_compile')
for name in c.NAMES:
    for condition in ('baseline','candidate'):
        rows=[r for r in profiles['rows'] if r['condition']==condition and r['case']==name]
        out['profile_medians_ms'].append({'case':name,'condition':condition,
           'total_ms':1000*st.median(r['total_seconds'] for r in rows),
           'functions':{f:1000*st.median(sum(x['cumulative_seconds'] for x in r['stats'] if x['function']==f) for r in rows) for f in functions}})
(c.OUT/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'original_sha256':out['original_sha256'], 'original_block_lower_bounds':out['original_block_lower_bounds'],
                  'frozen_copies_match_original_provider_files':out['frozen_copies_match_original_provider_files']},indent=2))
