import json
import os
from pathlib import Path
import subprocess
import sys
import time

state=Path('<verification-temp>/hook-resilience-v1-t11')
freeze=json.loads((state/'freeze.json').read_text())
mode=sys.argv[1]
label=sys.argv[2] if len(sys.argv)>2 else mode
cases=sys.argv[3:]
assert mode in ('resources','timing')
evidence=Path(freeze['evidence_dir'])
output=evidence/(label+'.json')
raw=evidence/(label+'.raw.log')
summary=evidence/(label+'-execution.json')
assert not output.exists() and not raw.exists() and not summary.exists()
env=os.environ.copy()
for key in tuple(env):
    if key.startswith(('COPILOT_OBSERVABILITY_','GEMINI_OBSERVABILITY_','OBSERVABILITY_')) or key in ('AUDIT_LOG','AUDIT_LOCK','AUDIT_PASSIVE_LOG_SHADOW_LOG','GEMINI_PASSIVE_SHADOW_LOG','SKIP_TOOL_GUARD','TOOL_GUARD_ALLOWLIST'):
        env.pop(key)
home=state/('driver-home-'+label)
home.mkdir()
env.update(HOME=str(home),CODEX_HOME=str(home/'.codex'),XDG_CONFIG_HOME=str(home/'.config'),XDG_CACHE_HOME=str(home/'.cache'),XDG_DATA_HOME=str(home/'.local/share'),OBSERVABILITY_TESTING='1',OBSERVABILITY_LOG_PATH=str(home/'observability.jsonl'),PYTHONPYCACHEPREFIX=str(state/'driver-pycache'))
command=['rtk','proxy','python3','scripts/verify-hook-release.py','--baseline-root',freeze['baseline_root'],'--candidate-root',freeze['candidate_root'],'--mode',mode,'--output',str(output)]
for case in cases:
    command.extend(['--case',case])
started=time.monotonic()
lines=0
with raw.open('x') as log:
    process=subprocess.Popen(command,cwd=freeze['candidate_root'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
    for line in process.stdout:
        log.write(line)
        log.flush()
        lines+=1
        if lines==1 or lines%12==0:
            print(f'{time.monotonic()-started:.1f}s {line.strip()}',flush=True)
    code=process.wait()
record={'command':command,'candidate':freeze['candidate'],'mode':mode,'case_filter':cases,'exit_code':code,'elapsed_seconds':round(time.monotonic()-started,6),'progress_lines':lines,'output':str(output),'raw_log':str(raw)}
summary.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record),flush=True)
raise SystemExit(code)
