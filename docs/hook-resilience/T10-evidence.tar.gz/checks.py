import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path('/Users/adam/.codex/worktrees/hook-performance-repair/skills')
evidence = Path('/private/tmp/hook-resilience-t10-tests')
evidence.mkdir(exist_ok=True)
commands = [
    ['python3', 'scripts/test-security-banners.py'],
    ['python3', 'scripts/test-tool-guard-native-data.py'],
    ['python3', 'scripts/test-tool-guard-shell-data.py'],
    ['python3', 'scripts/test-tool-guard-limits.py'],
    ['python3', 'scripts/test-tool-guard-false-positives.py'],
    ['bash', 'scripts/test-hooks-tool-guard.sh'],
    ['bash', 'scripts/test-gemini-hooks-tool-guard.sh'],
    ['bash', 'scripts/test-codex-hooks-tool-guard.sh'],
    ['python3', '-W', 'error', 'scripts/test_helpers.py'],
    ['python3', 'scripts/test-hook-diagnostics.py'],
    ['python3', 'scripts/test-hook-diagnostic-recovery.py'],
    ['python3', 'scripts/test-scan-secrets-stream-component.py'],
    ['python3', 'scripts/test-scan-secrets-streaming.py'],
    ['bash', 'scripts/test-codex-hooks-secrets-scanner.sh'],
    ['bash', 'scripts/test-hooks-secrets-scanner.sh'],
    ['bash', 'scripts/test-gemini-hooks-secrets-scanner.sh'],
    ['bash', 'scripts/test-hooks-observability.sh'],
    ['bash', 'scripts/test-gemini-hooks-observability.sh'],
    ['bash', 'scripts/test-hooks-startup.sh'],
    ['bash', 'scripts/test-gemini-hooks-startup.sh'],
    ['bash', 'scripts/test-codex-hooks-startup.sh'],
    ['bash', 'scripts/test-hooks-okf-lint.sh'],
    ['bash', 'scripts/test-gemini-hooks-okf-lint.sh'],
    ['bash', 'scripts/test-codex-repository-okf.sh'],
    ['bash', 'scripts/test-hooks-auto-ingest.sh'],
    ['bash', 'scripts/test-gemini-hooks-auto-ingest.sh'],
    ['bash', 'scripts/test-hooks-rtk.sh'],
    ['bash', 'scripts/test-gemini-hooks-rtk.sh'],
]
results = []
for index, command in enumerate(commands):
    log = evidence / (command[-1].split('/')[-1] + '.log')
    env = dict(os.environ)
    # Generic logging fallback stays disposable. Suites retain their own
    # provider-specific overrides and isolated HOME/configuration authorities.
    env['OBSERVABILITY_LOG_PATH'] = str(evidence / 'shell-observability.jsonl')
    print('RUN', index + 1, '/', len(commands), ' '.join(command), flush=True)
    started = time.monotonic()
    with log.open('wb') as stream:
        run = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT)
    result = dict(command=command, exit_code=run.returncode, seconds=round(time.monotonic() - started, 3), log=str(log))
    results.append(result)
    (evidence / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print('DONE', result['exit_code'], result['seconds'], str(log), flush=True)
    if run.returncode:
        print(log.read_text()[-12000:], flush=True)
sys.exit(any(row['exit_code'] for row in results))
